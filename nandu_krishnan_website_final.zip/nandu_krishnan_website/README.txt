NANDU KRISHNAN — PERSONAL WEBSITE DRAFT

Open index.html in a browser. Keep the assets folder beside index.html.

The visual portfolio uses cocktail-only editorial images. It contains no random people.
Your own supplied portrait remains the only person photograph.

Before publishing, verify CV dates, roles, qualifications and achievements. Add a public professional email only if you want it displayed. Connect a domain and hosting provider, then add the live site to Google Search Console.

This is a website draft, not yet hosted publicly.
